-- Top 3 from Products
SELECT TOP 3 * FROM Products;
-- Top 3 from Sales
SELECT TOP 3 * FROM Sales;

-- Top 3 from Customers
SELECT TOP 3 * FROM Customers;

-- Top 3 from Orders
SELECT TOP 3 * FROM Orders;

-- Top 3 from Order_Line
SELECT TOP 3 * FROM Order_Line;

-- Top 3 from Suppliers
SELECT TOP 100 * FROM Suppliers;

-- Top 3 from Inventory
SELECT TOP 3 * FROM Inventory;
